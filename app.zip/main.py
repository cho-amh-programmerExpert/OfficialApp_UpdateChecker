import flet as ft
from flet.security import encrypt, decrypt
from flet_webview import WebView as ft_WebView
import toml, requests, time
import pandas as pd
import socket
from src.subprocess_tasks.update import download_update

# ======== App Info ======== #

APP_NAME = "DataVL App"

APP_VERSION = "v0.0.9"
APP_VERCHECK = "https://raw.githubusercontent.com/cho-amh-programmerExpert/OfficialApp_UpdateChecker/refs/heads/main/version.toml"
APP_DIRECT_DOWNLOAD_LINK = "https://raw.githubusercontent.com/..."
APP_FILENAME = __name__

SITE_URL = "https://data-vl.amhf-astraium.net/"

# ======== App Info: UI ======== #

APP_VERSION__BADGE = ft.Badge(f"{APP_VERSION}", bgcolor=ft.Colors.INDIGO_400)

# ======== Main ======== #

def ofc_app(page: ft.Page):
    # ======== Update ======== #

    def software_update() -> dict:
        response = requests.get(APP_VERCHECK)

        ver_config = toml.loads(response.text)

        return {"new_update": not (APP_VERSION == ver_config['version']), "info": ver_config, 'failed': False}

    # ======== Helper Functions (Global) ======== #

    def copy(text: str, to_close=None):
        page.set_clipboard(text)
        page.open(ft.SnackBar(ft.Row([
            ft.Icon(ft.Icons.COPY_ALL),
            ft.Text("Copied To Clipboard!")
        ])))

        if to_close is not None:
            page.close(to_close)
    
    # ======== Main (Inner) ======== #

    def APP():
        # --- Update Check --- #

        def update_handler():
            global update_info
            checking_update_spinner = ft.Row(
                [
                    ft.ProgressRing(),
                    ft.Text("Checking For Updates...")
                ]
            )
            page.add(checking_update_spinner)

            try:
                update_info = software_update()
            except:
                update_info = {'new_update': False, 'failed': True}

            
            page.remove(checking_update_spinner)
            page.update()

        update_handler()

        update_available = "", "", ""
        if update_info['new_update']:
            update_base_str = f"Update Available: {update_info['info']['version']}-{update_info['info']['release_type']}"
            update_available = f" ({update_base_str})"

        
        # --- Title --- #

        page.title = f"{APP_NAME} | {APP_VERSION}{update_available}"
        platform = page.platform

        # --- Theme --- #

        if 'theme' not in page.client_storage.get_keys(''):
            page.client_storage.set('theme', 'System')
        theme = page.client_storage.get('theme')
        if theme == 'Light':
            theme_obj = ft.ThemeMode.LIGHT
        elif theme == 'Dark':
            theme_obj = ft.ThemeMode.DARK
        else:
            theme_obj = ft.ThemeMode.SYSTEM
        page.theme_mode = theme_obj
        page.update()

        # --- Tools Setup --- #

        if 'todo' not in page.client_storage.get_keys(''):
            page.client_storage.set('todo', {})

        # --- Main Body --- #

        # --> Home

        def home__home():
            # --- "Update" Banner --- #

            if update_info['new_update']:
                update_banner = ft.Banner(
                    content=ft.Container(ft.Column(controls=[ft.Text("New Update is Available!", weight=ft.FontWeight.BOLD), ft.Text(f"{update_info['info']['version']} ⩩ {update_info['info']['release_type']}", weight=ft.FontWeight.BOLD, theme_style=ft.TextThemeStyle.BODY_SMALL, color=ft.Colors.GREEN_ACCENT_100)])),
                    actions=[ft.TextButton("Download Update", on_click=lambda e: download_update(APP_DIRECT_DOWNLOAD_LINK, APP_FILENAME, APP_NAME, update_info['info']['version']), icon=ft.Icons.DOWNLOAD_ROUNDED, style=ft.ButtonStyle(color=ft.Colors.BLUE_900), tooltip=ft.Tooltip("Redirects you to the download page.", enable_feedback=True))],

                    bgcolor=ft.Colors.BLUE_ACCENT_100,
                    leading=ft.Column([ft.Icon(ft.Icons.UPDATE_OUTLINED, color=ft.Colors.BLUE_ACCENT)])
                )
                page.open(update_banner)
            else:
                if update_info['failed']:
                    failed_update_banner = ft.Banner(
                    content=ft.Container(ft.Row(controls=[ft.Text("Failed to check for updates.")])),
                    actions=[ft.TextButton("Retry", on_click=lambda e: APP(), icon=ft.Icons.REPLAY_OUTLINED), ft.TextButton("Ignore", icon=ft.Icons.CLOSE, on_click=lambda e: page.close(failed_update_banner))],

                    bgcolor=ft.Colors.AMBER_100,
                    leading=ft.Column([ft.Icon(ft.Icons.UPDATE)])
                )
                    page.open(failed_update_banner)

            # --- Home Body --- #

            # --> Tab: DataVL Site
            ht1 = [
                ft_WebView(
                    SITE_URL,
                    enable_javascript=True,
                    javascript_enabled=True
                )
            ]


            # --> Tab: Echo Series
            EchoSeries = {
                "EchoGeo": "Echo_Geo",
                "Echo Mathematics": "Echo_Mathematics",
                "EchoMeet": "EchoMeet",
                "EchoDrive": "EchoDrive",
                "EchoVideo": "EchoVideo",
                "EchoSound": "EchoSound",
                "EchoTube": "EchoTube",
                "EchoMail": "EchoMail",
                "EchoNode": "EchoNode",
                "Echo Shop Manager": "Echo_Shop_Manager"
            }
            ht2 = [
                ft.Row(
                    controls=[
                        ft.Container(
                            ft.Column([
                                ft.Text(x, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_ACCENT),
                                ft.Row([
                                    ft.IconButton(ft.Icons.COPY_ALL_OUTLINED, tooltip=ft.Tooltip("Copy URL To Clipboard"), on_click=lambda e: copy(f"{SITE_URL}{EchoSeries[x]}/")),
                                    ft.IconButton(ft.Icons.MORE_OUTLINED, tooltip=ft.Tooltip("More options"), on_click=lambda e: page.open(
                                        ft.BottomSheet(
                                            ft.Column([
                                                ft.Text("Options:", weight=ft.FontWeight.BOLD),
                                                ft.Row([
                                                    ft.IconButton(ft.Icons.OPEN_IN_BROWSER_OUTLINED, tooltip=ft.Tooltip("Open Page"), on_click=lambda e: page.launch_url(f"{SITE_URL}{EchoSeries[x]}/")),
                                                    ft.IconButton(ft.Icons.COPY_ALL_OUTLINED, tooltip=ft.Tooltip("Copy URL To Clipboard"), on_click=lambda e: copy(f"{SITE_URL}{EchoSeries[x]}/")),
                                                ], alignment=ft.alignment.center)
                                            ], height=100, width=130, alignment=ft.alignment.center), dismissible=True
                                        )
                                    ))
                                ])
                            ]),
                            border_radius=ft.border_radius.all(8), width=150, bgcolor=ft.Colors.GREY_100, alignment=ft.alignment.center
                        ) for x in EchoSeries.keys()
                    ],
                    wrap=True,
                    run_spacing=40
                )
            ]


            page.add(ft.Tabs(
                expand=1,
                selected_index=0,
                tabs=[
                    ft.Tab("DataVL", content=ft.Column(controls=ht1), icon=ft.Icons.BOLT_OUTLINED),
                    ft.Tab("Echo Series", content=ft.Column(controls=ht2), icon=ft.Icons.PAGES_ROUNDED),
                ],
                tab_alignment=ft.TabAlignment.CENTER, animation_duration=350
            ))
        
        # --> Quick Tools

        def quicktools__todo():
            def add_todo(e):
                e = toadd
                loading_todo = ft.Row([ft.ProgressRing(), ft.Text("Adding...")])
                page.add(loading_todo)
                todo = dict(page.client_storage.get('todo')).keys()
                page.remove(loading_todo)
                if not (toadd.value in todo or toadd.value ==""):
                    l = dict(page.client_storage.get('todo'))
                    l.update({e.value: False})
                    page.client_storage.set('todo', l)

                    todo_added_modal = ft.AlertDialog(
                        modal=True,
                        title=ft.Row([ft.Icon(ft.Icons.CHECK_BOX, color=ft.Colors.GREEN_ACCENT), ft.Text("Task Appended", theme_style=ft.TextThemeStyle.TITLE_MEDIUM)]),
                        content=ft.Row([ft.Text("Successfully added new task:"), ft.Text(e.value, weight=ft.FontWeight.BOLD, italic=True)]),
                        actions=[
                            ft.Column([
                                ft.OutlinedButton("Ok", on_click=lambda e: page.close(todo_added_modal))
                            ])
                        ]
                    )
                    
                    prepair("Quick Tools → To-Do")
                    quicktools__todo()
                    
                else:
                    if toadd.value =="":
                        todo_added_modal = ft.AlertDialog(
                            modal=True,
                            title=ft.Row([ft.Icon(ft.Icons.ERROR_OUTLINE, color=ft.Colors.ERROR), ft.Text("Error", theme_style=ft.TextThemeStyle.TITLE_MEDIUM)]),
                            content=ft.Row([ft.Text("You can't add an empty task.")]),
                            actions=[
                                ft.Column([
                                    ft.OutlinedButton("Ok", on_click=lambda e: page.close(todo_added_modal))
                                ])
                            ], 
                        )
                    else:
                        todo_added_modal = ft.AlertDialog(
                            modal=True,
                            title=ft.Row([ft.Icon(ft.Icons.ERROR_OUTLINE, color=ft.Colors.ERROR), ft.Text("Error", theme_style=ft.TextThemeStyle.TITLE_MEDIUM)]),
                            content=ft.Row([ft.Text("The entered task"), ft.Text(e.value, weight=ft.FontWeight.BOLD, italic=True), ft.Text("does already exists.")]),
                            actions=[
                                ft.Column([
                                    ft.OutlinedButton("Ok", on_click=lambda e: page.close(todo_added_modal))
                                ])
                            ], 
                        )


                page.open(
                    todo_added_modal
                )
            
            def remove_todo(task: str):
                def del_todo():
                    page.close(confirm_deletion)
                    page.update()

                    l = dict(page.client_storage.get('todo'))
                    l.pop(task)

                    page.client_storage.set('todo', l)
                    
                    page.open(
                        ft.SnackBar(
                            ft.Row([ft.Icon(ft.Icons.DELETE, color=ft.Colors.RED_ACCENT_200), ft.Text("Successfully deleted:", weight=ft.FontWeight.BOLD), ft.Text(task, italic=True)])
                        )
                    )

                    prepair("Quick Tools → To-Do")
                    quicktools__todo()

                confirm_deletion = ft.AlertDialog(
                    modal=True,
                    title=ft.Row([ft.Icon(ft.Icons.DELETE, color=ft.Colors.RED_ACCENT_200), ft.Text("Deletion Of", weight=ft.FontWeight.BOLD), ft.Text(task, weight=ft.FontWeight.BOLD, italic=True)]),
                    content=ft.Row([ft.Text("Are you sure that you want to delete"), ft.Text(task, weight=ft.FontWeight.BOLD), ft.Text("?")]),
                    actions=[ft.Button("Cancel", icon=ft.Icons.CANCEL_OUTLINED, on_click=lambda e: page.close(confirm_deletion)), ft.Button("Delete Forever", icon=ft.Icons.DELETE_FOREVER_ROUNDED, color=ft.Colors.RED_ACCENT_400, on_click=lambda e: del_todo())]
                )
                page.open(confirm_deletion)

            def del_all_tasks():
                def del_all_todo():
                    if page.client_storage.get('todo') != {}:
                        fake_spinner = ft.ProgressRing()
                        fake_spinner_text = ft.Text("Deletion Progress - 0%", weight=ft.FontWeight.BOLD)

                        page.add(ft.Row([fake_spinner, fake_spinner_text]))

                        strt = 10

                        time.sleep(0.45)
                        page.close(confirm_deletion)
                        fake_spinner.value = strt/100
                        fake_spinner_text.value = f"Deletion Progress - {strt}%"
                        page.update()

                        tasks_lenght = len(page.client_storage.get('todo'))
                        percentage_pertask = (90) / tasks_lenght

                        for idx, _ in enumerate(list(range(tasks_lenght))):
                            idx += 1
                            new_val =  strt + percentage_pertask*(idx)
                            fake_spinner.value = new_val/100
                            fake_spinner_text.value = f"Deletion Progress - {new_val}%"
                            time.sleep(1)
                            page.update()

                        page.client_storage.set('todo', {})
                        
                        page.open(
                            ft.SnackBar(
                                ft.Row([ft.Icon(ft.Icons.DELETE, color=ft.Colors.RED_ACCENT_200), ft.Text("Successfully deleted every task.", weight=ft.FontWeight.BOLD)])
                            )
                        )

                        prepair("Quick Tools → To-Do")
                        quicktools__todo()
                    else:
                        delalltasks_modal = ft.AlertDialog(
                            modal=True,
                            title=ft.Row([ft.Icon(ft.Icons.ERROR_OUTLINE, color=ft.Colors.ERROR), ft.Text("Error", theme_style=ft.TextThemeStyle.TITLE_MEDIUM)]),
                            content=ft.Row([ft.Text("There are no tasks available.")]),
                            actions=[
                                ft.Column([
                                    ft.OutlinedButton("Ok", on_click=lambda e: page.close(delalltasks_modal))
                                ])
                            ], 
                        )
                        page.open(delalltasks_modal)

                confirm_deletion = ft.AlertDialog(
                    modal=True,
                    title=ft.Row([ft.Icon(ft.Icons.DELETE, color=ft.Colors.RED_ACCENT_200), ft.Text("Deletion Of All Tasks", weight=ft.FontWeight.BOLD)]),
                    content=ft.Row([ft.Text("Are you sure that you want to delete all tasks?")]),
                    actions=[ft.Button("Cancel", icon=ft.Icons.CANCEL_OUTLINED, on_click=lambda e: page.close(confirm_deletion)), ft.Button("Delete All", icon=ft.Icons.DELETE_FOREVER_ROUNDED, color=ft.Colors.RED_ACCENT_400, on_click=lambda e: del_all_todo())]
                )
                page.open(confirm_deletion)
        

            window_width = page.window.width
            toadd = ft.TextField(
                label=ft.Text("New Task", weight=ft.FontWeight.BOLD), prefix_icon=ft.Icons.CHECK_BOX,
                hint_text="Wash the dishes", width=window_width*(0.6)
            )
            page.add(ft.Row([
                toadd,ft.Button("Add Task", icon=ft.Icons.ADD, on_click=add_todo, tooltip=ft.Tooltip("Add Task"), style=ft.ButtonStyle(enable_feedback=True, text_style=ft.TextStyle(weight=ft.FontWeight.BOLD)), width=window_width*(0.2)),
                ft.OutlinedButton("Delete All", on_click=lambda e: del_all_tasks(), width=window_width*(0.2))
            ], wrap=True))



            page.add(ft.Divider())


            tasks = {
                'All': {
                    'icon': ft.Icons.TASK,
                    'items': []
                },
                'Remaining': {
                    'icon': ft.Icons.UNARCHIVE,
                    'items': []
                },
                'Done': {
                    'icon': ft.Icons.CHECK_BOX,
                    'items': []
                },
            }
            todo_storage = dict(page.client_storage.get('todo'))
            for x in list(todo_storage.keys()):
                def save_task(e: ft.Control, task: str):
                    todo_storage[task] = e.control.value
                    page.client_storage.set('todo', todo_storage)
                    page.add(
                        ft.SnackBar(
                            ft.Row([
                                ft.Icon(ft.Icons.SAVED_SEARCH),
                                ft.Text("Successfully Completed Task:", weight=ft.FontWeight.BOLD),
                                ft.Text(x, italic=True, weight=ft.FontWeight.BOLD)
                            ]), dismiss_direction=ft.DismissDirection.END_TO_START, show_close_icon=True
                        )
                    )
                    prepair("Quick Tools → To-Do")
                    quicktools__todo()

                def edit_todo(task: str):
                    def edit_todo__inner():
                        page.close(edit_dialog)
                        page.update()

                        old_state = todo_storage[task]
                        todo_storage.update({new_task_name.value: old_state})  # Add the new task name
                        todo_storage.pop(task)  # Remove the old task
                        page.client_storage.set('todo', todo_storage)

                        page.add(
                            ft.SnackBar(
                                ft.Row([
                                    ft.Icon(ft.Icons.SAVED_SEARCH),
                                    ft.Text("Successfully edited task:", weight=ft.FontWeight.BOLD),
                                    ft.Text(task, italic=True, weight=ft.FontWeight.BOLD)
                                ]),
                                dismiss_direction=ft.DismissDirection.END_TO_START,
                                show_close_icon=True
                            )
                        )

                        prepair("Quick Tools → To-Do")
                        quicktools__todo()

                    # Create the modal dialog for editing
                    new_task_name = ft.TextField(
                        value=task,  # Pre-fill with the current task name
                        label=ft.Text("New Task Name"),
                        helper=ft.Text(f"Editing {task}")
                    )
                    edit_dialog = ft.AlertDialog(
                        modal=True,
                        title=ft.Row([
                            ft.Icon(ft.Icons.EDIT),
                            ft.Text("Editing", weight=ft.FontWeight.BOLD),
                            ft.Text(task, weight=ft.FontWeight.BOLD, italic=True)
                        ]),
                        content=ft.Row([new_task_name], wrap=True),
                        actions=[
                            ft.Button("Cancel", icon=ft.Icons.CANCEL_OUTLINED, on_click=lambda e: page.close(edit_dialog)),
                            ft.Button("Edit", icon=ft.Icons.EDIT, on_click=lambda e: edit_todo__inner())
                        ]
                    )
                    page.open(edit_dialog)


                val = todo_storage[x]
                task_checkbox = ft.Checkbox(label=x, value=val, label_style=ft.TextStyle(weight=ft.FontWeight.BOLD, size=20), visible=True, on_change=lambda e, task=x: save_task(e, task))

                edit_task_btn = ft.IconButton(
                    ft.Icons.EDIT,
                    tooltip=ft.Tooltip("Edit Task"),
                    on_click=lambda e, task=x: edit_todo(task)  # Bind the current value of x to task
                )

                del_task_btn = ft.IconButton(ft.Icons.DELETE, tooltip=ft.Tooltip("Delete Task"), on_click=lambda e, task=x: remove_todo(task))
                # save_task_btn = ft.Button("Save State", icon=ft.Icons.SAVE_OUTLINED, tooltip=ft.Tooltip(f"Save the state of {x}"), on_click=lambda e, task=x, checkbox=task_checkbox: save_task(e, task, checkbox))
                list_item = ft.ListTile(
                    leading=ft.Column([task_checkbox]), 
                    trailing=ft.Container(ft.Row([edit_task_btn, del_task_btn,], wrap=True))
                )
                

                tasks["All"]['items'].append(list_item)
                if val:
                    tasks['Done']['items'].append(list_item)
                else:
                    tasks['Remaining']['items'].append(list_item)

            for todo_cat in tasks.keys():
                if tasks[todo_cat]['items'] == []:
                    tasks[todo_cat]['items'].append(ft.Row([ft.Text("No tasks available as"), ft.Text(todo_cat, weight=ft.FontWeight.BOLD)]))
                else:
                    items_lenght = len(tasks[todo_cat]['items'])
                    s_suffix = "s" if items_lenght >= 2 else ""
                    if items_lenght >= 2:
                        is_or_are = "are"
                        s_suffix = "s"
                    else:
                        is_or_are = "is"
                        s_suffix = ""
                        
                    tasks[todo_cat]['items'].insert(0, ft.Row([ft.Text(items_lenght, weight=ft.FontWeight.BOLD, theme_style=ft.TextThemeStyle.BODY_SMALL), ft.Text(f"task{s_suffix} {is_or_are} available.", theme_style=ft.TextThemeStyle.BODY_SMALL)]))

            page.add(
                ft.Tabs(
                    expand=1,
                    selected_index=0,
                    tabs=[
                        ft.Tab(todo_cat, content=ft.Column(controls=tasks[todo_cat]['items']), icon=tasks[todo_cat]['icon']) 
                        for todo_cat in tasks.keys()],
                    tab_alignment=ft.TabAlignment.CENTER, animation_duration=350, 
                )
            )
        
        def quicktools__quick_charts():
            file_uploaded = False
            data = None  # Placeholder to store uploaded data

            def picked_files(e: ft.FilePickerResultEvent):
                nonlocal file_uploaded, data
                if e.files:
                    path = e.files[0].path
                    name = e.files[0].name
                    size = round((e.files[0].size) / (1024**2), 2)

                    try:
                        data = pd.read_csv(path)  # Load the CSV into a DataFrame
                        file_uploaded = True
                    except Exception as ex:
                        file_uploaded = False
                        selected_filename.value = f"Error loading file: {ex}"
                        selected_filename.update()
                        return

                    selected_filename.value = name
                    selected_filename.tooltip = ft.Tooltip(f"{size}MB → {path}")
                    close_file.visible = True
                    close_file.update()
                    selected_filename.update()

                    # Ensure the page updates here
                    page.update()

                    dialog = ft.BottomSheet(ft.Column(
                        [
                            ft.Text("Alert", color=ft.Colors.ORANGE_ACCENT, theme_style=ft.TextThemeStyle.HEADLINE_SMALL, text_align=ft.TextAlign.CENTER, font_family='Kanit'),
                            ft.Row([ft.Text("Charts in the"), ft.Text(APP_NAME, weight=ft.FontWeight.BOLD), ft.Text("are still under development.")]),
                            ft.Text("In the meantime, you can use different kinds of charts available in DataVL site:"),
                            ft.OutlinedButton("View Charts", icon=ft.Icons.PIE_CHART_OUTLINE, on_click=lambda e: page.launch_url(f"{SITE_URL}Data_Visualization"), tooltip=ft.Tooltip("Opens the DataVisualization page."),  width=325)
                        ],
                        width=450, height=150, alignment=ft.MainAxisAlignment.SPACE_AROUND
                    ))
                    page.add(
                        dialog
                    )
                    page.open(dialog)

                else:
                    file_uploaded = False
                    page.update()

            def clear_uploadedfile():
                nonlocal file_uploaded, data
                file_uploaded = False
                data = None
                prepair("Quick Tools → Quick Charts")
                quicktools__quick_charts()

            file_picker = ft.FilePicker(on_result=picked_files)
            page.add(file_picker)

            selected_filename = ft.Text(
                "Please pick a file first.", weight=ft.FontWeight.BOLD
            )
            close_file = ft.IconButton(
                ft.Icons.CLOSE, on_click=lambda e: clear_uploadedfile(), visible=False
            )
            page.add(
                ft.Row(
                    [
                        ft.Button(
                            "Pick File",
                            icon=ft.Icons.UPLOAD_FILE_OUTLINED,
                            style=ft.ButtonStyle(
                                text_style=ft.TextStyle(weight=ft.FontWeight.BOLD)
                            ),
                            on_click=lambda e: file_picker.pick_files(
                                dialog_title="Selecting CSV file to analyze",
                                file_type=ft.FilePickerFileType.CUSTOM,
                                allow_multiple=False,
                                allowed_extensions=["csv"],
                            ),
                            width=page.window.width
                        ),
                        close_file,
                        selected_filename,
                    ],
                    wrap=True,
                )
            )

        # --> App Info
        def appinfo__settings():
            # --- Software Update --- #

            if update_info['new_update']:
                update_exp = ft.ExpansionPanel(
                    header=ft.Row([ft.Icon(ft.Icons.UPDATE_ROUNDED, color=ft.Colors.INDIGO), ft.Text("Update Available!", weight=ft.FontWeight.BOLD, color=ft.Colors.ORANGE_ACCENT_400)]),
                    content=ft.ListTile(
                        title=ft.Text(f"{update_info['info']['version']} ⨠ {update_info['info']['release_type']}", weight=ft.FontWeight.BOLD),
                        subtitle=ft.Row([ft.Text(f"Current Version: ", weight=ft.FontWeight.BOLD), ft.Text(f"{APP_VERSION}")]),
                        trailing=ft.IconButton(ft.Icons.DOWNLOAD_ROUNDED, on_click=lambda e: page.launch_url(SITE_URL), tooltip=ft.Tooltip("Opens the download page."))
                    ),
                    bgcolor=ft.Colors.INDIGO_100
                )
                panel_exp = ft.ExpansionPanelList(controls=[
                    update_exp
                ])
                page.add(panel_exp)

            # --- Settings --- #

            def save_changes(e):
                page.theme_mode = getattr(ft.ThemeMode, theme_selector.value.upper())
                if save_config.value:
                    page.client_storage.set('theme', theme_selector.value)


                page.open(ft.SnackBar(content=ft.Row(controls=[ft.Icon(ft.Icons.SAVE, color=ft.Colors.INDIGO_300), ft.Text("Succssfully Saved Changes!")])))
                page.update()

            save_config = ft.Switch("Save Configurations", label_position=ft.LabelPosition.LEFT, value=True, label_style=ft.TextStyle(color=ft.Colors.ORANGE_ACCENT))
            page.add(
                ft.Row(controls=[
                        ft.Icon(ft.Icons.SETTINGS_ROUNDED, size=30),
                        ft.Text("Settings", theme_style=ft.TextThemeStyle.DISPLAY_SMALL),
                        ft.Container(ft.Row([ft.ElevatedButton("Apply Changes", icon=ft.Icons.SAVE, on_click=save_changes),
                        save_config]), bgcolor=ft.Colors.AMBER_100, border_radius=ft.border_radius.all(8))
                    ]
                ),
            )

            # --> Changing Theme

            curr_theme = page.client_storage.get("theme")
            theme_selector = ft.RadioGroup(
                content=ft.Row(
                    controls=[    
                        ft.Row([ft.Icon(ft.Icons.DESKTOP_WINDOWS), ft.Radio(label="System", value="System", label_position=ft.LabelPosition.LEFT)]),
                        ft.Row([ft.Icon(ft.Icons.LIGHT_MODE), ft.Radio(label="Light", value="Light", label_position=ft.LabelPosition.LEFT)]),
                        ft.Row([ft.Icon(ft.Icons.DARK_MODE), ft.Radio(label="Dark", value="Dark", label_position=ft.LabelPosition.LEFT)])
                    ]
                ), value=curr_theme
            )
            page.add(ft.Column(controls=[ft.Text("Theme:", theme_style=ft.TextThemeStyle.TITLE_MEDIUM, weight=ft.FontWeight.BOLD), theme_selector]))


            # Divider

            page.add(ft.Divider())

            # --> Info

            if platform == ft.PagePlatform.WINDOWS:
                os_str = "Window"
                os_str_ts = "Windows"
                os_color = "blue"
            elif platform == ft.PagePlatform.ANDROID:
                os_str = "Android"
                os_str_ts = "Android"
                os_color = "GREEN_ACCENT_700"
            elif platform == ft.PagePlatform.IOS:
                os_str = "Apple"
                os_str_ts = "IOS"
                os_color = "grey"

            page.add(
                ft.Row(
                    controls=[
                        ft.Icon(ft.Icons.INFO_ROUNDED, color=ft.Colors.LIGHT_BLUE), ft.Text("App Info: ", weight=ft.FontWeight.BOLD, theme_style=ft.TextThemeStyle.TITLE_MEDIUM),
                        ft.Text(f"{APP_NAME}", weight=ft.FontWeight.BOLD, color=ft.Colors.ORANGE_500, theme_style=ft.TextThemeStyle.BODY_MEDIUM, badge=APP_VERSION__BADGE),
                    ],
                    
                ),
                ft.Row(
                    controls=[
                        ft.Text("⬤ Operating System: ", weight=ft.FontWeight.BOLD, theme_style=ft.TextThemeStyle.TITLE_MEDIUM),
                        ft.Icon(getattr(ft.Icons, os_str.upper()), size=30, color=getattr(ft.Colors, os_color.upper())), 
                        ft.Text(os_str_ts, italic=True, theme_style=ft.TextThemeStyle.BODY_MEDIUM, weight=ft.FontWeight.BOLD)
                    ]
                ),
            )

        # --> Local Chat
        def quicktools__local_chat():
            server = None
            client_socket = None
            chat_messages = ft.ListView(expand=True, spacing=10, padding=20, auto_scroll=True)
            
            def show_snackbar(message: str, icon: str, color: str):
                page.open(ft.SnackBar(
                    content=ft.Row([
                        ft.Icon(icon, color=color),
                        ft.Text(message, weight=ft.FontWeight.BOLD)
                    ]),
                    bgcolor=ft.Colors.with_opacity(0.1, color),
                    duration=3000
                ))

            def clear_chat(e):
                chat_messages.controls.clear()
                page.update()
                show_snackbar("Chat history cleared", ft.Icons.CLEAR_ALL, ft.Colors.BLUE)

            def send_message(e):
                if client_socket:
                    message = message_input.value
                    if message:
                        try:
                            client_socket.sendall(message.encode('utf-8'))
                            # Get the local IP address
                            hostname = socket.gethostname()
                            local_ip = socket.gethostbyname(hostname)
                            
                            chat_messages.controls.append(
                                ft.Container(
                                    content=ft.Column([
                                        ft.Row([
                                            ft.Icon(ft.Icons.PERSON, color=ft.Colors.BLUE),
                                            ft.Text(local_ip, color=ft.Colors.BLUE, weight=ft.FontWeight.BOLD),
                                            ft.Container(
                                                content=ft.Text("You", color=ft.Colors.WHITE, size=12, weight=ft.FontWeight.BOLD),
                                                bgcolor=ft.Colors.BLUE_ACCENT_400,
                                                border_radius=10,
                                                padding=ft.padding.symmetric(horizontal=8, vertical=2)
                                            )
                                        ]),
                                        ft.Text(message, color=ft.Colors.BLUE)
                                    ]),
                                    bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.BLUE),
                                    border_radius=10,
                                    padding=10,
                                    margin=5
                                )
                            )
                            message_input.value = ""
                            page.update()
                        except Exception as e:
                            show_snackbar(f"Error sending message: {str(e)}", ft.Icons.ERROR, ft.Colors.RED)
                else:
                    show_snackbar("Not connected to any chat!", ft.Icons.WARNING, ft.Colors.ORANGE)

            def accept_connections():
                while True:
                    try:
                        client, addr = server.accept()
                        chat_messages.controls.append(
                            ft.Container(
                                content=ft.Column([
                                    ft.Row([
                                        ft.Icon(ft.Icons.CONNECT_WITHOUT_CONTACT, color=ft.Colors.GREEN),
                                        ft.Text(f"New connection from {addr[0]}", 
                                                color=ft.Colors.GREEN, weight=ft.FontWeight.BOLD)
                                    ])
                                ]),
                                bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.GREEN),
                                border_radius=10,
                                padding=10,
                                margin=5
                            )
                        )
                        page.update()
                        
                        while True:
                            data = client.recv(1024)
                            if not data:
                                break
                            message = data.decode('utf-8')
                            # Only show the message if it's not from the local client
                            if addr[0] != socket.gethostbyname(socket.gethostname()):
                                chat_messages.controls.append(
                                    ft.Container(
                                        content=ft.Column([
                                            ft.Row([
                                                ft.Icon(ft.Icons.PERSON, color=ft.Colors.PURPLE),
                                                ft.Text(f"{addr[0]}", color=ft.Colors.PURPLE, weight=ft.FontWeight.BOLD)
                                            ]),
                                            ft.Text(message, color=ft.Colors.PURPLE)
                                        ]),
                                        bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.PURPLE),
                                        border_radius=10,
                                        padding=10,
                                        margin=5
                                    )
                                )
                                page.update()
                    except Exception as e:
                        chat_messages.controls.append(
                            ft.Container(
                                content=ft.Column([
                                    ft.Row([
                                        ft.Icon(ft.Icons.ERROR, color=ft.Colors.RED),
                                        ft.Text("Connection error", color=ft.Colors.RED, weight=ft.FontWeight.BOLD)
                                    ]),
                                    ft.Text(str(e), color=ft.Colors.RED)
                                ]),
                                bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.RED),
                                border_radius=10,
                                padding=10,
                                margin=5
                            )
                        )
                        page.update()
                        break
            
            

            message_input = ft.TextField(
                hint_text="Type your message here...",
                on_submit=send_message,
                expand=True,
                border_radius=10,
                prefix_icon=ft.Icons.CHAT_BUBBLE_OUTLINE
            )

            

            def start_server(e):
                nonlocal server
                try:
                    port = int(port_input.value)
                    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    server.bind(('0.0.0.0', port))
                    server.listen(1)
                    show_snackbar(f"Server started on port {port}", ft.Icons.CHECK_CIRCLE, ft.Colors.GREEN)
                    
                    
                    
                except Exception as e:
                    show_snackbar(f"Error starting server: {str(e)}", ft.Icons.ERROR, ft.Colors.RED)

            def connect_to_chat(e):
                nonlocal client_socket
                try:
                    host = host_input.value
                    port = int(port_input.value)
                    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    client_socket.connect((host, port))
                    chat_messages.controls.append(
                        ft.Container(
                            content=ft.Column([
                                ft.Row([
                                    ft.Icon(ft.Icons.CONNECT_WITHOUT_CONTACT, color=ft.Colors.GREEN),
                                    ft.Text(f"Connected to {host}:{port}", color=ft.Colors.GREEN, weight=ft.FontWeight.BOLD)
                                ])
                            ]),
                            bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.GREEN),
                            border_radius=10,
                            padding=10,
                            margin=5
                        )
                    )
                    import threading
                    threading.Thread(target=accept_connections, daemon=True).start()
                    page.update()
                    
                    def receive_messages():
                        while True:
                            try:
                                data = client_socket.recv(1024)
                                if not data:
                                    break
                                message = data.decode('utf-8')
                                # Only show the message if it's not from the local client
                                if host != socket.gethostbyname(socket.gethostname()):
                                    chat_messages.controls.append(
                                        ft.Container(
                                            content=ft.Column([
                                                ft.Row([
                                                    ft.Icon(ft.Icons.PERSON, color=ft.Colors.PURPLE),
                                                    ft.Text("Server", color=ft.Colors.PURPLE, weight=ft.FontWeight.BOLD)
                                                ]),
                                                ft.Text(message, color=ft.Colors.PURPLE)
                                            ]),
                                            bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.PURPLE),
                                            border_radius=10,
                                            padding=10,
                                            margin=5
                                        )
                                    )
                                    page.update()
                            except Exception as e:
                                chat_messages.controls.append(
                                    ft.Container(
                                        content=ft.Column([
                                            ft.Row([
                                                ft.Icon(ft.Icons.ERROR, color=ft.Colors.RED),
                                                ft.Text("Connection error", color=ft.Colors.RED, weight=ft.FontWeight.BOLD)
                                            ]),
                                            ft.Text(str(e), color=ft.Colors.RED)
                                        ]),
                                        bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.RED),
                                        border_radius=10,
                                        padding=10,
                                        margin=5
                                    )
                                )
                                page.update()
                                break
                    
                    import threading
                    threading.Thread(target=receive_messages, daemon=True).start()
                    
                except Exception as e:
                    show_snackbar(f"Error connecting: {str(e)}", ft.Icons.ERROR, ft.Colors.RED)

            def close_connection(e):
                nonlocal server, client_socket
                try:
                    if server:
                        server.close()
                        server = None
                    if client_socket:
                        client_socket.close()
                        client_socket = None
                    chat_messages.controls.append(
                        ft.Container(
                            content=ft.Column([
                                ft.Row([
                                    ft.Icon(ft.Icons.CLOSE, color=ft.Colors.RED),
                                    ft.Text("Connection closed", color=ft.Colors.RED, weight=ft.FontWeight.BOLD)
                                ])
                            ]),
                            bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.RED),
                            border_radius=10,
                            padding=10,
                            margin=5
                        )
                    )
                    page.update()
                    show_snackbar("Connection closed successfully", ft.Icons.CHECK_CIRCLE, ft.Colors.GREEN)
                except Exception as e:
                    show_snackbar(f"Error closing connection: {str(e)}", ft.Icons.ERROR, ft.Colors.RED)

            port_input = ft.TextField(
                hint_text="Enter port number",
                value="5000",
                width=150,
                border_radius=10,
                prefix_icon=ft.Icons.NUMBERS
            )

            host_input = ft.TextField(
                hint_text="Enter host IP",
                value="localhost",
                width=200,
                border_radius=10,
                prefix_icon=ft.Icons.COMPUTER
            )

            controls = ft.Container(
                content=ft.Row([
                    port_input,
                    host_input,
                    ft.ElevatedButton(
                        "Start Server",
                        on_click=start_server,
                        style=ft.ButtonStyle(
                            bgcolor=ft.Colors.GREEN_ACCENT_200,
                            color=ft.Colors.WHITE
                        ),
                        icon=ft.Icons.PLAY_ARROW
                    ),
                    ft.ElevatedButton(
                        "Connect",
                        on_click=connect_to_chat,
                        style=ft.ButtonStyle(
                            bgcolor=ft.Colors.BLUE_ACCENT_200,
                            color=ft.Colors.WHITE
                        ),
                        icon=ft.Icons.CONNECT_WITHOUT_CONTACT
                    ),
                    ft.ElevatedButton(
                        "Close",
                        on_click=close_connection,
                        style=ft.ButtonStyle(
                            bgcolor=ft.Colors.RED_ACCENT_200,
                            color=ft.Colors.WHITE
                        ),
                        icon=ft.Icons.CLOSE
                    ),
                    ft.ElevatedButton(
                        "Clear Chat",
                        on_click=clear_chat,
                        style=ft.ButtonStyle(
                            bgcolor=ft.Colors.ORANGE_ACCENT_200,
                            color=ft.Colors.WHITE
                        ),
                        icon=ft.Icons.CLEAR_ALL
                    )
                ]),
                padding=10,
                bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.BLUE_GREY),
                border_radius=10
            )

            page.add(
                controls,
                ft.Container(
                    content=chat_messages,
                    border=ft.border.all(1, ft.Colors.OUTLINE),
                    border_radius=10,
                    padding=10,
                    expand=True,
                    bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.BLUE_GREY)
                ),
                ft.Container(
                    content=ft.Row([
                        message_input,
                        ft.ElevatedButton(
                            "Send",
                            on_click=send_message,
                            style=ft.ButtonStyle(
                                bgcolor=ft.Colors.BLUE_ACCENT_200,
                                color=ft.Colors.WHITE
                            ),
                            icon=ft.Icons.SEND
                        )
                    ]),
                    padding=10,
                    bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.BLUE_GREY),
                    border_radius=10
                )
            )

        # --- Drawer --- #

        def return_navbar(title: str, home: bool=False):
            header_elements = [
                ft.IconButton(ft.Icons.MENU, on_click=lambda e: page.open(drawer), tooltip=ft.Tooltip("Open navigation drawer", trigger_mode=ft.TooltipTriggerMode.LONG_PRESS)),
                ft.Text(title, theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM, weight=ft.FontWeight.BOLD, badge=APP_VERSION__BADGE if home else None),
            ]

            page.add(ft.Row(
                header_elements
            ))

        def prepair(title: str=APP_NAME):
            page.clean()
            page.update()
            return_navbar(title, home=(title==APP_NAME))
            page.update()

        def change_navbar(e):
            idx = e.control.selected_index

            if idx==0:
                prepair()
                home__home()
            if idx==1:
                prepair("Quick Tools → To-Do")
                quicktools__todo()
            if idx==2:
                prepair("Quick Tools → Local Chat")
                quicktools__local_chat()    
            if idx==3:
                prepair("Quick Tools → Quick Charts")
                quicktools__quick_charts()
            if idx==4:
                prepair("App Info → Settings & App Info")
                appinfo__settings()

            page.update()

        nav_header_elements = [ft.Text(f"{APP_NAME}", theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM, weight=ft.FontWeight.BOLD, size=25, badge=APP_VERSION__BADGE)]


        drawer = ft.NavigationDrawer(
            controls=[

                ft.Row(controls=nav_header_elements),

                ft.Row(
                    controls=[ft.Icon(ft.Icons.HOME_OUTLINED),
                    ft.Text("Home")]
                ),
                ft.NavigationDrawerDestination(label="Home", icon=ft.Icons.BOLT_ROUNDED, selected_icon=ft.Icons.BOLT),
                
                ft.Divider(),

                ft.Row(
                    controls=[ft.Icon(ft.Icons.INFO_ROUNDED),
                    ft.Text("Quick Tools")]
                ),
                ft.NavigationDrawerDestination(label="To-Do", icon=ft.Icons.CHECK_CIRCLE),
                ft.NavigationDrawerDestination(label="Local Chat", icon=ft.Icons.CHAT_ROUNDED),
                ft.NavigationDrawerDestination(label="Quick Charts", icon=ft.Icons.ANALYTICS_OUTLINED),

                ft.Divider(),

                ft.Row(
                    controls=[ft.Icon(ft.Icons.INFO_ROUNDED),
                    ft.Text("App")]
                ),
                ft.NavigationDrawerDestination(label="Settings", icon=ft.Icons.SETTINGS)
            ],
            on_change=change_navbar,
            selected_index=0
        )


        # --- UI Start --- #

        prepair()
        home__home()


    # --- App Start --- #

    APP()


ft.app(ofc_app)